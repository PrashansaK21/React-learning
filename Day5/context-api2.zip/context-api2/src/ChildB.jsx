import React from 'react'
import ChildC from './ChildC'

const ChildB = () => {
  return (
    <ChildC/>
  )
}

export default ChildB