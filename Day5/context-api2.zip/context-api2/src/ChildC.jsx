import React from 'react'
import { fName, lName } from './App'

const ChildC = () => {
  return (
    <>
    <fName.Consumer>
      {
        (fName)=>{
          return(
            <lName.Consumer>
              {
                (lName)=>{
                  return(
                    <h1>My Name is {fName} last name is {lName}</h1>


                  )
                }
              }
            </lName.Consumer>
            

          )

        }
      }

    </fName.Consumer>

    </>
  )
}

export default ChildC

