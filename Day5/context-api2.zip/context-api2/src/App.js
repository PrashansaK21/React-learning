
import './App.css';

import { createContext } from 'react';
import ChildA from './ChildA';


const fName =createContext();
const lName = createContext();
const App = () => {

  return (
    <>
    <fName.Provider value={"Prashansa"}>
    <lName.Provider value={"Kamalpuriya"}>
    <ChildA/>
    </lName.Provider>
    </fName.Provider>
    </>
  )
}

export default App;
export {fName};
export {lName};

