import logo from './logo.svg';
import './App.css';
import Item from './components/Item'
import Cart from './components/Cart';

function App(){
  return (
    <div className="App">
      <Item name="MacBook Pro" price={100000} />
      <Item name="Pendrive" price={3000} />
      <Item name="Mobile" price={40000} />
      <Cart/>

      
    </div>
  )
}
export default App;
