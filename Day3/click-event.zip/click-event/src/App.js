import logo from './logo.svg';
import './App.css';

function App() {
  function apple(){
    alert("function called");
  }
  return (
    <div className="App">
      <h1>Hello World</h1>
      
      <button onClick={()=>apple()}>Click Me</button>
      {/* <button onClick={()=>alert("hello")}>Click Me</button> */}

      
    </div>
  );
}

export default App;
