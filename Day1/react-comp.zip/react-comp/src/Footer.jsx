import React from 'react'

export default function Footer() {
  return (
    <h1>Footer Section</h1>
  )
}
