import React from 'react';

function List(){
    return (
        <ol>
            <li>React js</li>
            <li>BootStrap</li>
            <li>Node js</li>
        </ol>
    );
}

export default List;