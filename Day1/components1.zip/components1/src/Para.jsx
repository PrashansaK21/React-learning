import React from "react";

function Para(){
    return(
        <p>This is my page</p>
    )
}

export default Para;