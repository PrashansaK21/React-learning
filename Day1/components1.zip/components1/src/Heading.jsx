import Raect from 'react';

function Heading(){
    return(
        <h1>My Name is Prashansa</h1>
    )
}

export default Heading;