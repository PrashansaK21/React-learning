import logo from './logo.svg';
import './App.css';
import NewsApp from './Components/NewsApp';

function App() {
  return (
    <div className="App">
      <NewsApp />

    </div>
  );
}

export default App;
