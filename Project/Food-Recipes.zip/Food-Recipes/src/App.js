import logo from './logo.svg';
import './App.css';
import Mainpage from './Component/MainPage';
import{Route,Routes} from 'react-router-dom';
import Mealinfo from './Component/Mealinfo';

function App() {
  return (
    <div className="App">

      <Routes>
        <Route path='/' element={<Mainpage/>}/>
        <Route path='/:mealid' element={<Mealinfo/>}/>
      </Routes>

      
    </div>
  );
}

export default App;
