export const questions=[{
    id:1,
    question:'Popular Articles',
    answer:'Reflect and respond to your audience needs wholly and thoroughly'

},
{
    id:2,
    question:'What information should I input when ordering?',
    answer:'our online ordering system will ask for all the important information you should submit. If you have a VAT number, please remember to submit it. This will make sure the shipment is not delayed because of the lack of VAT number'
},
{
    id:3,
    question:'What payment methods can I use?',
    answer:'You can use all the major credit cards.'
},
{
    id:4,
    question:'Can I cancel my order?',
    answer:'If you want to cancel your order, please do so as soon as possible. If we have already processed your order, you need to contact us and return the product'

}



]